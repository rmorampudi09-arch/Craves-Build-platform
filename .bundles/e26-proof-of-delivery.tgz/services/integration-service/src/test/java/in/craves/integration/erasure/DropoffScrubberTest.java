package in.craves.integration.erasure;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.craves.integration.config.PidgeProperties;
import in.craves.integration.delivery.pidge.PidgeApiClient;
import in.craves.integration.delivery.pidge.PidgeBookingRepository;
import in.craves.integration.delivery.pidge.PidgeTransport;
import in.craves.integration.delivery.provider.DeliveryProviderAdapter.QuoteRequest;
import in.craves.integration.delivery.provider.DeliveryProviderAdapter.ShipmentItem;
import in.craves.integration.delivery.provider.DeliveryProviderAdapter.Stop;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;

/** The customer's drop-off is replaced in the shapes Craves and its delivery providers store; the pickup and the rider are not. */
class DropoffScrubberTest {
    private final ObjectMapper json = new ObjectMapper().enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);

    private JsonNode parse(String text) throws Exception {
        return json.readTree(text);
    }

    @Test
    void aCravesDropoffLosesNameAddressAndCoordinatesButKeepsTheAreaAndThePickup() throws Exception {
        JsonNode tree = parse("""
            {"orderId":"o-1","deliveryRequest":{"declaredGoodsValue":433.10,
              "pickup":{"address":"Kitchen road 1","contactName":"Chef","contactPhone":"8888888888","latitude":17.4,"longitude":78.4},
              "dropoff":{"address":"12 Real Street, Flat 4","contactName":"Real Person","contactPhone":"9876543210",
                "latitude":17.4412345,"longitude":78.3912345,"note":"Gate code 1234","addressLine1":"12 Real Street",
                "addressLine2":"Flat 4","landmark":"Near Real Temple","area":"Madhapur","city":"Hyderabad","state":"Telangana",
                "postalCode":"500081","country":"India","requiredStart":null}}}""");

        assertTrue(DropoffScrubber.scrub(tree));

        JsonNode drop = tree.at("/deliveryRequest/dropoff");
        for (String key : new String[] {"address", "addressLine1", "addressLine2", "landmark", "note"}) {
            assertEquals(AccountErasureService.ERASED_TEXT, drop.get(key).asText(), key);
        }
        assertEquals(AccountErasureService.ERASED_NAME, drop.get("contactName").asText());
        assertEquals(AccountErasureService.ERASED_PHONE, drop.get("contactPhone").asText());
        assertEquals(AccountErasureService.ERASED_POSTAL_CODE, drop.get("postalCode").asText());
        assertEquals(0, drop.get("latitude").decimalValue().signum());
        assertEquals(0, drop.get("longitude").decimalValue().signum());
        assertEquals("Madhapur", drop.get("area").asText());
        assertEquals("Hyderabad", drop.get("city").asText());
        assertTrue(drop.get("requiredStart").isNull());
        assertEquals("Kitchen road 1", tree.at("/deliveryRequest/pickup/address").asText());
        assertEquals("8888888888", tree.at("/deliveryRequest/pickup/contactPhone").asText());
        assertEquals(0, new java.math.BigDecimal("17.4").compareTo(tree.at("/deliveryRequest/pickup/latitude").decimalValue()));
        assertEquals(0, new java.math.BigDecimal("433.10").compareTo(tree.at("/deliveryRequest/declaredGoodsValue").decimalValue()));
        assertFalse(DropoffScrubber.scrub(tree), "a second pass changes nothing");
    }

    @Test
    void aBorzoOrderKeepsItsPickupPointAndItsCourier() throws Exception {
        JsonNode tree = parse("""
            {"order":{"order_id":1250032,"payment_amount":"150.00","courier":{"name":"Rider Name","phone":"7777777777"},
              "points":[
                {"address":"Kitchen road 1","contact_person":{"name":"Chef","phone":"8888888888"},"latitude":"17.4","longitude":"78.4"},
                {"address":"12 Real Street, Flat 4","contact_person":{"name":"Real Person","phone":"9876543210"},
                 "latitude":"17.4412345","longitude":"78.3912345","note":"Gate code 1234","building_number":"12",
                 "apartment_number":"4","delivery_id":11712,"tracking_url":"https://tracking.example/11712",
                 "delivery":{"status":"parcel_picked_up"}}]}}""");

        assertTrue(DropoffScrubber.scrub(tree));

        JsonNode drop = tree.at("/order/points/1");
        assertEquals(AccountErasureService.ERASED_TEXT, drop.get("address").asText());
        assertEquals(AccountErasureService.ERASED_NAME, drop.at("/contact_person/name").asText());
        assertEquals(AccountErasureService.ERASED_PHONE, drop.at("/contact_person/phone").asText());
        assertEquals("0", drop.get("latitude").asText(), "a text coordinate stays text");
        assertEquals("0", drop.get("longitude").asText());
        assertEquals(AccountErasureService.ERASED_TEXT, drop.get("note").asText());
        assertEquals(AccountErasureService.ERASED_TEXT, drop.get("building_number").asText());
        assertEquals(AccountErasureService.ERASED_TEXT, drop.get("apartment_number").asText());
        assertEquals(11712, drop.get("delivery_id").asInt());
        assertEquals("https://tracking.example/11712", drop.get("tracking_url").asText());
        assertEquals("parcel_picked_up", drop.at("/delivery/status").asText());
        assertEquals("Kitchen road 1", tree.at("/order/points/0/address").asText());
        assertEquals("8888888888", tree.at("/order/points/0/contact_person/phone").asText());
        assertEquals("17.4", tree.at("/order/points/0/latitude").asText());
        assertEquals("Rider Name", tree.at("/order/courier/name").asText(), "the rider's own data stays");
        assertEquals("7777777777", tree.at("/order/courier/phone").asText());
        assertEquals("150.00", tree.at("/order/payment_amount").asText());
        assertFalse(DropoffScrubber.scrub(tree));
    }

    @Test
    void aPidgeDropAndShiprocketBillingFieldsAreReplaced() throws Exception {
        JsonNode tree = parse("""
            {"id":"p-1","drop":[{"ref":"craves-drop","poc_detail":{"name":"Real Person","mobile":"9876543210"},
               "address":{"address_line_1":"12 Real Street","address_line_2":"Flat 4","landmark":"Near Real Temple",
                 "instructions_to_reach":"Gate code 1234","city":"Hyderabad","pincode":"500081","latitude":17.44,"longitude":78.39}}],
             "billing_customer_name":"Real Person","billing_phone":"9876543210","billing_address":"12 Real Street",
             "billing_address_2":"Flat 4","billing_pincode":"500081","billing_city":"Hyderabad","courier":{"name":"Rider"}}""");

        assertTrue(DropoffScrubber.scrub(tree));

        String after = tree.toString();
        for (String personal : new String[] {"Real Person", "9876543210", "12 Real Street", "Flat 4", "Real Temple", "Gate code", "500081", "17.44", "78.39"}) {
            assertFalse(after.contains(personal), personal + " in " + after);
        }
        assertTrue(after.contains("Hyderabad") && after.contains("craves-drop") && after.contains("\"name\":\"Rider\""), after);
        assertFalse(DropoffScrubber.scrub(tree));
    }

    @Test
    void aPidgeBookingLosesItsReceiverButKeepsTheKitchen() throws Exception {
        // The body PidgeApiClient really builds and Craves stores: sender_detail and poc_detail are the kitchen,
        // trips[].receiver_detail is the customer.
        Stop kitchen = new Stop("Kitchen road 1", "Chef Kitchen", "+918888888888", new BigDecimal("17.4"), new BigDecimal("78.4"),
            null, null, null, "Kitchen road 1", null, null, "Kondapur", "Hyderabad", "Telangana", "500084", "IN");
        Stop customer = new Stop("12 Real Street, Flat 4", "Real Person", "+919876543210", new BigDecimal("17.4412345"),
            new BigDecimal("78.3912345"), null, null, "Gate code 1234", "12 Real Street", "Flat 4", "Near Real Temple", "Madhapur",
            "Hyderabad", "Telangana", "500081", "IN");
        QuoteRequest request = new QuoteRequest("Food", 500, false, kitchen, customer,
            List.of(new ShipmentItem(UUID.randomUUID(), "Meal", new BigDecimal("100"), 1, new BigDecimal("100"))),
            new BigDecimal("100"), "PREPAID", UUID.randomUUID());
        PidgeApiClient client = new PidgeApiClient(new PidgeProperties(), mock(PidgeTransport.class), mock(PidgeBookingRepository.class), json);
        Method buildOrder = PidgeApiClient.class.getDeclaredMethod("buildOrder", String.class, QuoteRequest.class);
        buildOrder.setAccessible(true);
        JsonNode tree = parse(buildOrder.invoke(client, "ref-1", request).toString());
        assertEquals("Real Person", tree.at("/trips/0/receiver_detail/name").asText(), "the fixture is the real shape");

        assertTrue(DropoffScrubber.scrub(tree));

        JsonNode receiver = tree.at("/trips/0/receiver_detail");
        assertEquals(AccountErasureService.ERASED_NAME, receiver.get("name").asText());
        assertEquals(AccountErasureService.ERASED_PHONE, receiver.get("mobile").asText());
        String after = receiver.toString();
        for (String personal : new String[] {"Real Person", "9876543210", "12 Real Street", "Flat 4", "Real Temple", "Gate code", "500081", "17.44", "78.39"}) {
            assertFalse(after.contains(personal), personal + " in " + after);
        }
        assertEquals("Hyderabad", receiver.at("/address/city").asText());
        assertEquals("Chef Kitchen", tree.at("/sender_detail/name").asText());
        assertEquals("8888888888", tree.at("/sender_detail/mobile").asText());
        assertEquals("Kitchen road 1", tree.at("/sender_detail/address/address_line_1").asText());
        assertEquals("8888888888", tree.at("/poc_detail/mobile").asText(), "the kitchen's contact person stays");
        assertEquals("ref-1", tree.at("/trips/0/reference_id").asText());
        assertFalse(DropoffScrubber.scrub(tree));
    }

    @Test
    void borzoAndPidgeProofOfDeliveryLosesTheRecipientAndThePhotoLinks() throws Exception {
        JsonNode tree = parse("""
            {"order":{"order_id":1250032,"points":[
              {"address":"Kitchen road 1","place_photo_url":"https://borzo.example/kitchen.jpg","checkin":{"recipient_full_name":"Chef"}},
              {"address":"12 Real Street","courier_visit_datetime":"2026-11-05T13:10:00+05:30","checkin_code":"4417",
               "place_photo_url":"https://borzo.example/real-door.jpg","sign_photo_url":"https://borzo.example/real-sign.jpg",
               "checkin":{"recipient_full_name":"Real Person","recipient_position":"Neighbour"}}]},
             "fulfillment":{"status":"DELIVERED","drop":{"proof":["https://pidge.example/real-door.jpg",{"url":"https://pidge.example/real.jpg","count":2},
               {"image":{"url":"https://pidge.example/real-deep.jpg"}},["https://pidge.example/real-nested.jpg"]]}}}""");

        assertTrue(DropoffScrubber.scrub(tree));

        String after = tree.toString();
        for (String personal : new String[] {"Real Person", "Neighbour", "real-door", "real-sign", "real.jpg", "real-deep", "real-nested"}) {
            assertFalse(after.contains(personal), personal + " in " + after);
        }
        assertEquals(AccountErasureService.ERASED_NAME, tree.at("/order/points/1/checkin/recipient_full_name").asText());
        assertEquals("2026-11-05T13:10:00+05:30", tree.at("/order/points/1/courier_visit_datetime").asText(), "the visit time stays");
        assertEquals("4417", tree.at("/order/points/1/checkin_code").asText(), "the code is not about the person");
        assertEquals("https://borzo.example/kitchen.jpg", tree.at("/order/points/0/place_photo_url").asText(), "the kitchen point stays");
        assertEquals("Chef", tree.at("/order/points/0/checkin/recipient_full_name").asText());
        assertEquals(2, tree.at("/fulfillment/drop/proof/1/count").asInt());
        assertEquals("DELIVERED", tree.at("/fulfillment/status").asText());
        assertFalse(DropoffScrubber.scrub(tree), "a second pass changes nothing");
    }

    @Test
    void textWithoutADropoffIsLeftAlone() throws Exception {
        JsonNode tree = parse("{\"order\":{\"points\":[{\"address\":\"only the pickup\"}]},\"dropoff\":null,\"drop\":[]}");
        assertFalse(DropoffScrubber.scrub(tree));
        assertFalse(DropoffScrubber.scrub(parse("[1,2,{\"points\":\"x\"}]")));
        assertFalse(DropoffScrubber.scrub(parse("{}")));
    }
}
