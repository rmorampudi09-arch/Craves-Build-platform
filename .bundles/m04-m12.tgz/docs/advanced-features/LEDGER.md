# Advanced features — build ledger

Source of truth for the recurring build cycle (scheduled task **"Craves advanced features build cycle"**, every 2 h).
Live copy: Craves-Dev project doc `claude/advanced-features-ledger.md` (update that one first; the repo copy follows with each PR).
How to build, ship and verify: `docs/advanced-features/PLAYBOOK.md` (project doc `claude/advanced-features-playbook.md`).

## Lease (only one session builds at a time)

```
LEASE: free
```

A run takes the lease by writing `LEASE: <session or run id> until <UTC time = now + 110 min>`. If the lease is held and not expired, the run stops without changes. Release it (`LEASE: free`) at the end of every run, success or not.

## Next steps (keep this list current)

1. Owner: run the one-time setup (see "Deployment status"). Until then rows stay MERGED; the smoke workflow on main reports "not published yet".
2. Shipping access (checked 31 Oct 07:55 UTC): the owner turned on "Require this computer", but at 08:19 UTC the scheduled task (now hourly at :28) still showed no computer, and the run that was "linked" got no browser or device tools. Ship from a task the owner starts on his computer (Claude's browser, signed in to GitHub): Chrome flow, playbook section 3. The GitHub connector reads the repo but every write is refused (`create_branch`: 403 "Resource not accessible by integration"): the connector route (playbook section 3, "Without Chrome") works only after the Claude GitHub app gets Contents and Pull requests write access to Craves-Build-platform. `git push` from the sandbox stays refused by the proxy ("not in this session's authorized repository set").
3. Ship the pending patches (built and tested, not yet on GitHub because the scheduled runs have no Chrome): in a fresh clone of main, `git apply` the files in `claude/advanced-features-pending/` in this order, each made on top of the previous: `m04-taxonomy`, `m05-menu-options`, `m06-taste-memory`, `m07-kitchen-capacity`, `m08-promotions`, `m09-bulk-orders`, `m10-corporate-meals`, `m22-erase-idempotency`, `m11-order-amendments`, `m12-trust` (all `.patch`). Re-run the build (step 2 of the playbook), copy this ledger to `docs/advanced-features/LEDGER.md`, then one bundle `bundle/m04-m12` (or one per module) through the bundle-import flow. The ten patches were checked together on a clean main 6691c44 on 31 Oct ~07:50 UTC: they apply in order, give exactly the tested tree, and the build passes with 117 tests (49 unit, 68 PostgreSQL integration), 14 contracts / 151 operations, live-runtime lock test and contract check green. They also carry the refreshed PLAYBOOK.md; copy the project playbook over it when shipping (it has the newer connector paragraph). On 31 Oct 07:53 UTC they also rebased cleanly onto main f02e055 (its only new commit touches rider-fleet APIM files).
4. Next modules to build: M13 experiments + product analytics (E30), then M14 onwards in table order. M13 prep: it must read M22's `productAnalytics` consent (defaults off) before recording anything about a person. The read-only `OrderGateway` (customer and chef order reads with the caller's token: lines, status, grand total, created/updated times) is in `platform.clients` since m11/m12, with `FakeOrders` for tests.
5. The repo copy of this ledger (docs/advanced-features/LEDGER.md) still shows the pre-merge statuses: refresh it in the next bundle (step 3). `claude/advanced-features-pending/advanced-features-smoke.yml` is already on main (#576): nothing to ship there.
6. Found while building M09: in production `CatalogGateway.menuItem` only returns dishes Catalog shows publicly (Catalog `getPublicMenuItem` filters `is_available = true`), although its javadoc (corrected in m09) and `FakeCatalog` said "available or not". Effect on main today: M01 food lists cannot add a dish that is switched off for today (`FoodListService` line 114), and M09 bulk requests cannot name one. Lifting it needs a Catalog read for active-but-unavailable dishes (catalog-service, outside the allow-list): owner decision.
7. For M24, from the M08 and M10 reviews: enforce per-person limits (promotion per-person limit, company meals per day and member cap) from order-service's own order history, because erasing taste data and coming back resets the counts kept here; and `quote`/`reserve` in M08/M10 hold a database connection while they ask Catalog (pool of 8 shared by all modules), so call Catalog before opening the transaction if the pool gets tight. From the M11 and M12 reviews: an amendment's `foodDeltaPaise` and a dispute's refund cap are at the order's own prices and grand total, before wallet and referral discounts, so M24 must share those discounts across the lines and never refund more than was paid; M24 must mark the amendments it applies (a V2 migration adds APPLIED) so they are not replayed over the updated order; Order service never writes `PREPARING` (an accepted order goes straight to `READY_FOR_PICKUP`).
8. Owner decisions recorded in `docs/advanced-features/modules.md` (all built the conservative way, easy to change): M11 lets customers ask for changes until the order is ready, because Order service has no "cooking started" status (the chef's answer is the gate); M12 support admins only read (Auth defines the role as read-only), so moderation is platform/compliance/operations and dispute decisions platform/payments; erasing taste data resets a person's daily report count and their person-summary dispute counts (a pseudonymous counter or an erase rate limit would close that); trust records about a person (reports naming them, risk flags) stay outside the self-service export/erase.

## Audit — 31 Oct 2026 (handbook of 31 Oct vs GitHub main 8a37e65)

Already on main, so **not rebuilt** (frontend can wire them now): favorites, favorite chefs/kitchens, favorite watches, Cooking Today feed (029-037), repeat candidates / reorder (038-040), kitchen schedule and overrides (025-027), discovery v2 filters (017-023), cart/checkout/orders (041-054), payments/refunds (055-063), delivery providers, Borzo→Pidge timed handoff, delivery-code verification (064-078, E24 partly, E26 partly), notification inbox (079-081), support cases (083-086), meal plans (087, E12), chef onboarding/admin (089-098), ratings and reviews with moderation (E18), scheduled orders (E11), Chef Academy (E32, kept switched off on purpose), chef referral (E33), chef ledger/settlements (E34), PDF documents/invoices (E35), own rider fleet (E27), support chat (E28).

Policy-gated by the handbook (built here as admin-configurable policy, never with invented values): serviceability rule (015), refund/cancellation rules (062), provider assignment ranking (072), notification frequency (088).

Frontend-only (no backend work): E37 premium motion, E38 mascot.

## Modules to build — new isolated service `services/advanced-features-service`

Each module has its own package, Postgres schema (`adv_<module>`), Flyway history, feature flag, APIM API, OpenAPI contract (`contracts/openapi/advanced/`), README and tests.

| ID | Module | Handbook | API prefix (via https://api.craves.in; one gateway API `craves-adv-v1` for all) | Status |
|---|---|---|---|---|
| M00 | Platform foundation (security, errors, correlation, module isolation, idempotency, audit) | 099-100, 104, 106 | `/api/v1/advanced/features`, `/modules` | MERGED — #576, main 6691c44 |
| M01 | Food lists — private + shareable | E04, E40 | `/api/v1/advanced/food-lists`, `/api/v1/advanced/shared-food-lists` | MERGED — #576 |
| M02 | Group ordering + shared carts | E13 | `/api/v1/advanced/group-orders` | MERGED — #576 |
| M03 | Ingredients, allergens, nutrition | E19 | `/api/v1/advanced/food-facts` | MERGED — #576 |
| M04 | Regional cuisine + dietary taxonomy | E10 | `/api/v1/advanced/taxonomy` | MERGED — PR from `bundle/m04-m12`; built and tested (44 tests green on PostgreSQL 16, contract `taxonomy-v1.yaml`, 12 operations) |
| M05 | Menu modifiers + meal-period menus | E16 | `/api/v1/advanced/menu-options` | MERGED — PR from `bundle/m04-m12`; built and tested (50 tests green with M04, contract `menu-options-v1.yaml`, 9 operations) |
| M06 | Remembered spice/oil/portion choices | E03 | `/api/v1/advanced/taste-memory` | MERGED — PR from `bundle/m04-m12`; built and tested (54 tests green with M04+M05, contract `taste-memory-v1.yaml`, 6 operations, covered by my-taste-data export/erase) |
| M07 | Kitchen capacity, dynamic prep time, small-batch reservations | E20, E05 | `/api/v1/advanced/kitchen-capacity` | MERGED — PR from `bundle/m04-m12`; small batches with portion holds (E05) and the chef's extra prep time (E20) built and tested (63 tests green with M04–M06, contract `kitchen-capacity-v1.yaml`, 11 operations; an independent review's 5 findings fixed: per-person cap of 50 portions, chef can void holds no real order backs, no holds after the India service date, Catalog asked before the row lock, 30 s expiry grace, unreadable hold setting falls back to 10 min). Capacity and prep time from live order counts moved to M24 (needs order-service) |
| M08 | Promotions, offers, coupons | E23 | `/api/v1/advanced/promotions` | MERGED — PR from `bundle/m04-m12`; built and tested in the 31 Oct 02:39 scheduled run (contract `promotions-v1.yaml`, 10 operations; staff set every value, nothing seeded; budget required; terms frozen once live; one promotion per order; reserve/confirm/release for M24). Independent review: no overspend, authorization or deadlock issue; its 2 defects and 2 nits fixed (pausing/ending never depends on Catalog, budget counts read only live rows through partial indexes, draft codes answer as unknown, 404 instead of 500 after an erase) |
| M09 | Party + bulk orders | E14 | `/api/v1/advanced/bulk-orders` | MERGED — PR from `bundle/m04-m12`; built and tested in the same run (contract `bulk-orders-v1.yaml`, 10 operations; request → chef quote with the staff-set deposit share → accept; rules have no defaults, so requests answer 503 until staff set min portions, notice, horizon and deposit). Independent review: no authorization or money hole; its findings fixed (lapsed requests no longer count as open, price bound against overflow, per-dish cap after merging, open cap checked before Catalog, impossible rules refused, other kitchens' requests answer 404) |
| M10 | Corporate + team meals | E15 | `/api/v1/advanced/corporate-meals` | MERGED — PR from `bundle/m04-m12`; built and tested in the 31 Oct 04:39 scheduled run (contract `corporate-meals-v1.yaml`, 21 operations; staff enter every term — share %, per-meal cap, meals a day, days and India-time window, monthly budget, optional member cap, payment terms — nothing seeded, so a company pays nothing until set; one company per person; invite codes shown once and stored hashed; reserve/confirm/release for M24 under the company row lock; team meals for managers; monthly statements with due date). Independent review: no high-severity issue; fixed: erase waits for a reservation in progress and unlinks invites, blank Unicode names refused, the CHECK blocks a NULL window, export includes names and invites; erase-and-rejoin resetting per-member limits documented for M24 (as M08) |
| M11 | Order amendments + substitutions | E17 | `/api/v1/advanced/order-amendments` | MERGED — PR from `bundle/m04-m12`; built and tested in the 31 Oct 06:39 scheduled run (contract `order-amendments-v1.yaml`, 13 operations): customer asks / chef answers or chef proposes a substitution / customer answers; REMOVE, REDUCE, REPLACE (same kitchen, never pricier), ADJUST; one waiting proposal per order, 5 per side, 10-minute answer window; accepted changes replay in sequence so nothing is refunded twice; nothing here refunds (M24). New read-only `OrderGateway` (caller's token). Independent review: no high issue; 2 medium (replica clock skew could accept a superseded proposal; erasure broke the order's sequence) and 7 low findings fixed or documented |
| M12 | Fraud risk, disputes, moderation | E29 | `/api/v1/advanced/trust` | MERGED — PR from `bundle/m04-m12`; built and tested in the same run (contract `trust-v1.yaml`, 18 operations): reports with a staff moderation queue; disputes on finished paid orders within a staff-set window (no default: 503 until set), chef statement, staff decision with a refund only for delivered orders and at most their total; risk flags and per-person/per-kitchen counts (no automatic scores). Independent review: 1 high (two people's open reports on one target blocked the second erasure) and 4 medium (erasure re-opened dispute rounds; second refunds on already refunded orders; staff deciding their own case; window from checkout broke scheduled orders) fixed, low ones fixed or documented |
| M13 | Experiments + product analytics | E30 | `/api/v1/advanced/experiments` | TODO |
| M14 | Post-order partner offers | E36 | `/api/v1/advanced/partner-offers` | TODO |
| M15 | Chef business analytics | E21 | `/api/v1/advanced/chef-insights` | TODO |
| M16 | Demand forecasting | E22 | `/api/v1/advanced/demand-forecast` | TODO |
| M17 | Enriched Saved feed, unavailable-favorite recovery, familiarity | E01, E02, E06 | `/api/v1/advanced/saved-feed` | TODO |
| M18 | Personalized ranking | E07 | `/api/v1/advanced/personalized` | TODO |
| M19 | Semantic search | E09 | `/api/v1/advanced/semantic-search` | TODO |
| M20 | Conversational AI search | E08 | `/api/v1/advanced/ai-search` | TODO |
| M21 | Live order activity (Dynamic Island) | E39 | `/api/v1/advanced/live-activities` | TODO |
| M22 | Private taste data (export, delete, consent) | E40 | `/api/v1/advanced/my-taste-data` | MERGED — #576 (later modules must implement PersonalDataContributor). Erase also deletes the person's stored idempotency replies (PR from `bundle/m04-m12`) |
| M23 | Policy engines: serviceability, cancellation/refund, provider ranking, notification frequency | 015, 062, 072, 088 | `/api/v1/advanced/policies` | TODO |
| M24 | Checkout hooks in order-service (options pricing via M05 quote, coupons, batch hold confirm/release from M07, kitchen-wide capacity and prep time from live order counts) — additive, flag default off, canary | E05, E16, E20, E23 | order-service | TODO |
| M25 | Delivery exceptions + reassignment console | E25 | integration-service | TODO |

Statuses: TODO → BUILDING → MERGED (on main) → LIVE (deployed, APIM routes published, smoke-tested through api.craves.in) or BLOCKED (reason).

## Deployment status

**Waiting for the one-time Azure setup.** On 31 Oct the automation's safety check refused to create production Azure resources from the owner's browser, so the owner runs this once in Azure Cloud Shell (Bash, ravitejamm6@gmail.com):

```
curl -fsSL https://raw.githubusercontent.com/rmorampudi09-arch/Craves-Build-platform/main/infra/advanced-features/setup-once.sh | bash
```

It creates everything below and the release pipeline; afterwards every merge deploys itself and the "Advanced features live smoke" workflow checks api.craves.in. Build runs must not try to change Azure from the browser; they ship code to main, then read the smoke workflow result. Rows go MERGED → LIVE when the smoke workflow passes after the setup.

## Infrastructure (fill in as created)

| Item | Value |
|---|---|
| Resource group | rg-craves-advanced-prod |
| Container app | ca-craves-advanced-prod |
| Key Vault | kv-crv-advanced-34eefd |
| Database | craves_advanced_db on pg-craves-business-prod |
| NAT egress IP | – |
| Maven cache for the sandbox | branch `ci/advanced-features-m2` (workflow "Advanced features dependency cache") |
| Scheduled task | "Craves advanced features build cycle", trig_01LSqbY1o5cwxWKNqJfGRGSV, hourly at :28 UTC (since 31 Oct 07:28) |
| DevOps pipeline | release-advanced |
| APIM API | `craves-adv-v1`, path `api/v1/advanced`, wildcard operations, policy `infra/apim/advanced-features/api-policy.xml` |

## Run log

- 2026-10-31 — ledger created from the audit.
- 2026-10-31 00:35 UTC — PR #576 merged (main 6691c44) after all 17 checks passed (Exact-SHA regression 25 min). Azure provisioning from the browser was refused by the safety check; one-time setup handed to the owner.
- 2026-10-31 — interactive session: built M00, M01, M02, M03, M22 (33 tests green on PostgreSQL 16, contracts + APIM routes generated); workflows bundle-import, dependency cache and service CI on branch bundle/advanced-features-foundation.
- 2026-10-31 00:40–01:35 UTC scheduled run: built M04 taxonomy, M05 menu options, M06 taste memory, M07 small batches + kitchen load on main 6691c44 (63 tests green; 4 new contracts, 38 operations; independent review found 5 issues in M07, all fixed and tested). Not shipped: no Chrome in scheduled runs (GH token in the sandbox is invalid); stacked patches saved in `claude/advanced-features-pending/`. Smoke not checked (nothing new merged; one-time setup still pending).
- 2026-10-31 02:39–03:40 UTC scheduled run: m04–m07 re-checked on main 6691c44 (63 tests green); built M08 promotions and M09 bulk orders (84 tests green on PostgreSQL 16; 2 new contracts, 20 operations); an independent review of each, all findings fixed; whole m04–m09 stack checked on a clean main. Not shipped: no Chrome in scheduled runs (GH token invalid). Smoke not readable from the sandbox (the proxy blocks api.craves.in and the GitHub API); nothing new merged, so rows unchanged.
- 2026-10-31 06:39–07:55 UTC scheduled run: main still 6691c44; m04–m10 + m22 re-checked (94 tests green); built M11 order amendments (13 operations, new read-only OrderGateway) and M12 trust (18 operations); an independent review of each (M11: 2 medium, 7 low; M12: 1 high, 4 medium, 8 low), all fixed or documented; the whole ten-patch stack checked on a clean main (117 tests green: 49 unit, 68 PostgreSQL integration; 14 contracts / 151 operations; tree identical to the tested one). Playbook: replica clock skew and Order service's missing PREPARING noted. Not shipped: no Chrome in scheduled runs (GH token invalid, no GitHub API access); smoke result unreadable from the sandbox; merged rows unchanged.
- 2026-10-31 04:39–05:25 UTC scheduled run: main still 6691c44; m04–m09 re-checked (84 tests green); built M10 corporate and team meals (21 operations) and the Next-steps platform fix (erase deletes idempotency replies, patch m22); independent review of M10 (2 medium, 4 low findings) fixed or documented; the whole m04–m10 + m22 stack checked on a clean main (94 tests green, 12 contracts / 120 operations, tree identical to the tested one). Playbook: how to get inline patches onto disk without retyping. Not shipped: no Chrome in scheduled runs (GH token invalid; the proxy blocks api.craves.in and the GitHub API, so the smoke result is unreadable); merged rows unchanged.
- 2026-10-31 07:52–08:05 UTC, same session after the owner turned on "Require this computer" and the GitHub connector: main had moved to f02e055 (rider-fleet APIM only) and the ten patches rebased cleanly. Not shipped: the connector refused the first write (`create_branch` 403 "Resource not accessible by integration"; reads work), `git push` is still refused by the proxy, and this run has no computer or Chrome. Nothing was written to GitHub. Playbook: connector route and its access prerequisite documented. Smoke unchanged (nothing merged).
- 2026-10-31 08:20–08:30 UTC, same session: owner asked to ship through a browser. This session never got the computer link (no browser or device tools appeared after "Link to this computer"), and the sandbox network refuses GitHub sign-in/API and every Azure host (login.microsoftonline.com, management.azure.com, dev.azure.com, portal.azure.com), so no cloud browser either. Bundle m04-m12.tgz (105 files, rebased on main f02e055) built and checked here; ship it from a task started on the owner's computer (Next steps 3). Lease released.
